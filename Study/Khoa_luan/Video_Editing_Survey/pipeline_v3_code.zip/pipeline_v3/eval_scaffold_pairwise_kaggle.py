"""
Standalone Pairwise 3D Scaffold Comparator for Kaggle (Zero-Dependency & Offline Ready).
Contains full MFS-Scaffold logic self-contained so it works regardless of Kaggle dataset sync state.
"""

import os
import sys
import glob
import time
import argparse
import numpy as np
import cv2
import torch
import torch.nn.functional as F
from typing import Optional, Tuple, List


# --------------------------------------------------------------------------
# 1. MFS-Scaffold Core Functions for Injection into Warper3D
# --------------------------------------------------------------------------
def compute_surface_normals(warper, depth: torch.Tensor, intrinsic: torch.Tensor) -> torch.Tensor:
    b, _, h, w = depth.shape
    device = depth.device
    dtype = depth.dtype

    x1d = torch.arange(0, w, device=device, dtype=dtype)[None]
    y1d = torch.arange(0, h, device=device, dtype=dtype)[:, None]
    x2d = x1d.repeat([h, 1])
    y2d = y1d.repeat([1, w])
    ones_2d = torch.ones(size=(h, w), device=device, dtype=dtype)
    pos_vectors = torch.stack([x2d, y2d, ones_2d], dim=0)[None]

    fx = intrinsic[:, 0:1, 0:1].unsqueeze(-1)
    fy = intrinsic[:, 1:2, 1:2].unsqueeze(-1)
    cx = intrinsic[:, 0:1, 2:3].unsqueeze(-1)
    cy = intrinsic[:, 1:2, 2:3].unsqueeze(-1)

    X = (pos_vectors[:, 0:1] - cx) / fx * depth
    Y = (pos_vectors[:, 1:2] - cy) / fy * depth
    Z = depth
    points_3d = torch.cat([X, Y, Z], dim=1)

    dx = torch.zeros_like(points_3d)
    dx[:, :, :, 1:-1] = (points_3d[:, :, :, 2:] - points_3d[:, :, :, :-2]) / 2.0
    dx[:, :, :, 0] = points_3d[:, :, :, 1] - points_3d[:, :, :, 0]
    dx[:, :, :, -1] = points_3d[:, :, :, -1] - points_3d[:, :, :, -2]

    dy = torch.zeros_like(points_3d)
    dy[:, :, 1:-1, :] = (points_3d[:, :, 2:, :] - points_3d[:, :, :-2, :]) / 2.0
    dy[:, :, 0, :] = points_3d[:, :, 1, :] - points_3d[:, :, 0, :]
    dy[:, :, -1, :] = points_3d[:, :, -1, :] - points_3d[:, :, -2, :]

    nx = dx[:, 1] * dy[:, 2] - dx[:, 2] * dy[:, 1]
    ny = dx[:, 2] * dy[:, 0] - dx[:, 0] * dy[:, 2]
    nz = dx[:, 0] * dy[:, 1] - dx[:, 1] * dy[:, 0]
    normals = torch.stack([nx, ny, nz], dim=1)

    norm = torch.norm(normals, dim=1, keepdim=True) + 1e-8
    normals = normals / norm

    ray = points_3d / (torch.norm(points_3d, dim=1, keepdim=True) + 1e-8)
    dot = (normals * ray).sum(dim=1, keepdim=True)
    normals = torch.where(dot > 0, -normals, normals)
    return normals


def compute_reliable_depth_mask(warper, depth: torch.Tensor, window_size: int = 5, ratio_thresh: float = 0.35) -> torch.Tensor:
    depth_pos = torch.clamp(depth, min=1e-4)
    local_max = F.max_pool2d(depth_pos, kernel_size=window_size, stride=1, padding=window_size // 2)
    local_min = -F.max_pool2d(-depth_pos, kernel_size=window_size, stride=1, padding=window_size // 2)
    local_mean = F.avg_pool2d(depth_pos, kernel_size=window_size, stride=1, padding=window_size // 2)
    ratio = (local_max - local_min) / (local_mean + 1e-6)
    reliable = ((ratio < ratio_thresh) & (depth > 0.05)).float()
    return reliable


def compute_grazing_angle_mask(warper, depth1: torch.Tensor, transformation1: torch.Tensor, transformation2: torch.Tensor, intrinsic1: torch.Tensor, max_angle_deg: float = 55.0) -> torch.Tensor:
    b, _, h, w = depth1.shape
    device = depth1.device
    dtype = depth1.dtype

    normals1 = compute_surface_normals(warper, depth1, intrinsic1)

    rel_transform = torch.bmm(
        transformation2.to(device, dtype),
        torch.linalg.inv(transformation1.to(device, dtype)),
    )
    R_rel = rel_transform[:, :3, :3]
    t_rel = rel_transform[:, :3, 3:]

    fx = intrinsic1[:, 0:1, 0:1].unsqueeze(-1)
    fy = intrinsic1[:, 1:2, 1:2].unsqueeze(-1)
    cx = intrinsic1[:, 0:1, 2:3].unsqueeze(-1)
    cy = intrinsic1[:, 1:2, 2:3].unsqueeze(-1)
    x1d = torch.arange(0, w, device=device, dtype=dtype)[None]
    y1d = torch.arange(0, h, device=device, dtype=dtype)[:, None]
    x2d = x1d.repeat([h, 1])
    y2d = y1d.repeat([1, w])
    X = (x2d[None, None] - cx) / fx * depth1
    Y = (y2d[None, None] - cy) / fy * depth1
    Z = depth1
    pts1 = torch.cat([X, Y, Z], dim=1)

    pts1_flat = pts1.view(b, 3, -1)
    pts2_flat = torch.bmm(R_rel, pts1_flat) + t_rel
    pts2 = pts2_flat.view(b, 3, h, w)

    normals1_flat = normals1.view(b, 3, -1)
    normals2_flat = torch.bmm(R_rel, normals1_flat)
    normals2 = normals2_flat.view(b, 3, h, w)
    normals2 = normals2 / (torch.norm(normals2, dim=1, keepdim=True) + 1e-8)

    ray2 = pts2 / (torch.norm(pts2, dim=1, keepdim=True) + 1e-8)
    cos_angle = -(ray2 * normals2).sum(dim=1, keepdim=True)

    cos_thresh = np.cos(np.deg2rad(max_angle_deg))
    valid_mask = (cos_angle > cos_thresh).float()
    valid_mask = valid_mask * (pts2[:, 2:3] > 0.05).float()
    return valid_mask


def align_depth_scale(warper, source_depth: torch.Tensor, target_depth: torch.Tensor, covisible_mask: torch.Tensor) -> torch.Tensor:
    device = source_depth.device
    src_inv = 1.0 / torch.clamp(source_depth, min=0.01, max=100.0)
    tgt_inv = 1.0 / torch.clamp(target_depth, min=0.01, max=100.0)

    mask = (covisible_mask > 0.5) & (source_depth > 0.1) & (target_depth > 0.1)
    if mask.sum() < 100:
        return source_depth

    x = src_inv[mask].unsqueeze(1)
    y = tgt_inv[mask].unsqueeze(1)
    ones = torch.ones_like(x)
    A = torch.cat([x, ones], dim=1)

    try:
        solution = torch.linalg.lstsq(A, y).solution
        scale = torch.clamp(solution[0, 0], min=0.2, max=5.0)
        bias = torch.clamp(solution[1, 0], min=-5.0, max=5.0)
        aligned_inv = src_inv * scale + bias
        aligned_depth = 1.0 / torch.clamp(aligned_inv, min=0.01, max=100.0)
        return aligned_depth
    except Exception:
        return source_depth


def multi_frame_forward_warp(
    warper,
    frames: torch.Tensor,
    depths: torch.Tensor,
    transformation_s: torch.Tensor,
    transformation_t: torch.Tensor,
    intrinsic_s: torch.Tensor,
    intrinsic_t: Optional[torch.Tensor] = None,
    target_idx: int = 0,
    neighbor_radius: int = 3,
    use_all_frames: bool = True,
    cull_grazing_angles: bool = True,
    max_grazing_angle: float = 55.0,
    filter_depth_edges: bool = True,
    align_depth_scale_flag: bool = True,
    clean_mask: bool = True,
    heal_holes: bool = True,
    max_hole_area: int = 25,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    num_frames = frames.shape[0]
    if intrinsic_t is None:
        intrinsic_t = intrinsic_s.clone()

    # Tier 0: Primary Anchor
    anchor_frame = frames[target_idx : target_idx + 1]
    anchor_depth = depths[target_idx : target_idx + 1]
    anchor_pose_s = transformation_s[target_idx : target_idx + 1]
    target_pose = transformation_t[target_idx : target_idx + 1]
    target_k = intrinsic_t[target_idx : target_idx + 1] if intrinsic_t.shape[0] > 1 else intrinsic_t
    anchor_k = intrinsic_s[target_idx : target_idx + 1] if intrinsic_s.shape[0] > 1 else intrinsic_s

    anchor_mask = None
    if cull_grazing_angles:
        g_mask = compute_grazing_angle_mask(warper, anchor_depth, anchor_pose_s, target_pose, anchor_k, max_grazing_angle)
        anchor_mask = g_mask
    if filter_depth_edges:
        r_mask = compute_reliable_depth_mask(warper, anchor_depth)
        anchor_mask = r_mask if anchor_mask is None else (anchor_mask * r_mask)

    canvas, canvas_mask, flow = warper.forward_warp(
        anchor_frame,
        anchor_mask,
        anchor_depth,
        anchor_pose_s,
        target_pose,
        anchor_k,
        target_k,
        clean_mask=False,
        heal_holes=False,
    )

    # Tier 1 & Tier 2 Candidates
    neighbors = []
    for r in range(1, neighbor_radius + 1):
        if target_idx - r >= 0:
            neighbors.append(target_idx - r)
        if target_idx + r < num_frames:
            neighbors.append(target_idx + r)

    remaining = []
    if use_all_frames:
        for idx in range(num_frames):
            if idx != target_idx and idx not in neighbors:
                remaining.append(idx)

    candidates = neighbors + remaining

    for cand_idx in candidates:
        if canvas_mask.mean().item() >= 0.98:
            break

        cand_depth = depths[cand_idx : cand_idx + 1]
        if align_depth_scale_flag:
            cand_depth = align_depth_scale(warper, cand_depth, anchor_depth, canvas_mask)

        cand_k = intrinsic_s[cand_idx : cand_idx + 1] if intrinsic_s.shape[0] > 1 else intrinsic_s
        cand_pose_s = transformation_s[cand_idx : cand_idx + 1]

        cand_mask = None
        if cull_grazing_angles:
            g_mask = compute_grazing_angle_mask(warper, cand_depth, cand_pose_s, target_pose, cand_k, max_grazing_angle)
            cand_mask = g_mask
        if filter_depth_edges:
            r_mask = compute_reliable_depth_mask(warper, cand_depth)
            cand_mask = r_mask if cand_mask is None else (cand_mask * r_mask)

        cand_warp, c_mask, _ = warper.forward_warp(
            frames[cand_idx : cand_idx + 1],
            cand_mask,
            cand_depth,
            cand_pose_s,
            target_pose,
            cand_k,
            target_k,
            clean_mask=False,
            heal_holes=False,
        )

        fill_region = (canvas_mask < 0.5) & (c_mask > 0.5)
        if fill_region.any():
            fill_mask_3c = fill_region.repeat(1, 3, 1, 1)
            canvas = torch.where(fill_mask_3c, cand_warp, canvas)
            canvas_mask = torch.where(fill_region, torch.ones_like(canvas_mask), canvas_mask)

    if heal_holes and max_hole_area > 0 and hasattr(warper, "heal_small_holes"):
        canvas, canvas_mask = warper.heal_small_holes(canvas, canvas_mask, max_hole_area=max_hole_area)
    if clean_mask and hasattr(warper, "clean_points"):
        canvas, canvas_mask = warper.clean_points(canvas, canvas_mask)

    return canvas, canvas_mask, flow


# --------------------------------------------------------------------------
# 2. Patching Warper3D class directly
# --------------------------------------------------------------------------
def patch_warper_class(Warper3D_cls):
    Warper3D_cls.compute_surface_normals = compute_surface_normals
    Warper3D_cls.compute_reliable_depth_mask = compute_reliable_depth_mask
    Warper3D_cls.compute_grazing_angle_mask = compute_grazing_angle_mask
    Warper3D_cls.align_depth_scale = align_depth_scale
    Warper3D_cls.multi_frame_forward_warp = multi_frame_forward_warp
    print("✅ [MFS-Scaffold] Đã nạp thành công 5 hàm xử lý hình học đa khung hình vào Warper3D!")


# --------------------------------------------------------------------------
# 3. Path Auto-Discovery
# --------------------------------------------------------------------------
def find_first_existing(patterns: List[str]) -> Optional[str]:
    for p in patterns:
        if os.path.exists(p):
            return p
        matches = glob.glob(p, recursive=True)
        if matches:
            return sorted(matches)[0]
    return None


def create_comparison_grid(
    input_path: str,
    old_render_path: str,
    new_render_path: str,
    old_gen_path: str,
    new_gen_path: str,
    out_grid_path: str,
    fps: int = 10,
):
    """Stitches a 5-column video comparison grid."""
    import torchvision
    from pipeline_v3.inference_v3 import save_video

    def load_vt(p):
        v, _, _ = torchvision.io.read_video(p, pts_unit="sec")
        return v.float() / 255.0

    t_in = load_vt(input_path)
    t_old_ren = load_vt(old_render_path)
    t_new_ren = load_vt(new_render_path)
    t_old_gen = load_vt(old_gen_path)
    t_new_gen = load_vt(new_gen_path)

    f = min(len(t_in), len(t_old_ren), len(t_new_ren), len(t_old_gen), len(t_new_gen))
    t_in, t_old_ren, t_new_ren, t_old_gen, t_new_gen = t_in[:f], t_old_ren[:f], t_new_ren[:f], t_old_gen[:f], t_new_gen[:f]
    h, w = t_old_gen.shape[1:3]

    if t_in.shape[1:3] != (h, w):
        t_in = F.interpolate(t_in.permute(0, 3, 1, 2), size=(h, w), mode="bilinear", align_corners=False).permute(0, 2, 3, 1)

    divider = torch.ones(f, h, 8, 3, device=t_in.device) * 0.15
    grid = torch.cat([t_in, divider, t_old_ren, divider, t_new_ren, divider, t_old_gen, divider, t_new_gen], dim=2)
    save_video(grid, out_grid_path, fps=fps, quiet=True)
    print(f"--> [Comparison Grid] Đã lưu video 5 cột so sánh tại: {out_grid_path}")


def run_pairwise_eval():
    print("===========================================================================")
    print("🚀 PIPELINE V3: BÀI TEST SO SÁNH THEO CẶP (3D SCAFFOLD CŨ vs MỚI)")
    print("===========================================================================")

    # Setup paths in Kaggle
    for p in ["/kaggle/working", "/kaggle/working/pipeline_v3", "."]:
        if os.path.exists(p) and p not in sys.path:
            sys.path.insert(0, p)

    # Auto-find resources
    model_dir = find_first_existing([
        "/kaggle/input/datasets/tranbao0105/cogvideox-fun-components/CogVideoX-Fun-V1.1-5b-InP",
        "/kaggle/input/**/CogVideoX-Fun-V1.1-5b-InP",
        "/kaggle/input/**/cogvideox-fun-inp*",
        "./checkpoints/CogVideoX-Fun-V1.1-5b-InP",
    ])
    transformer_dir = find_first_existing([
        "/kaggle/input/datasets/tranbao0105/trajectorycrafter-weights/TrajectoryCrafter",
        "/kaggle/input/**/TrajectoryCrafter*",
        "./checkpoints/TrajectoryCrafter",
    ])
    stage1_ckpt = find_first_existing([
        "/kaggle/input/datasets/tranbao0105/pipeline/dora_stage1_step2000/dora_stage1_step2000/data.pkl",
        "/kaggle/input/**/dora_stage1_step2000*/**/data.pkl",
        "/kaggle/input/**/dora_stage1*/**/data.pkl",
    ])
    stage2_ckpt = find_first_existing([
        "/kaggle/input/datasets/tranbao0105/pipeline/dora_stage2_step1000/dora_stage2_step1000/data.pkl",
        "/kaggle/input/**/dora_stage2*/**/data.pkl",
        "/kaggle/working/checkpoints/stage2_step1000.pt",
    ])
    video_path = find_first_existing([
        "/kaggle/input/datasets/tranbao0105/cameractrl-sota-weights/RealEstate10K_Mini/real-estate-10k-mini/test_256/000c3ab189999a83.mp4",
        "/kaggle/input/**/000c3ab189999a83.mp4",
        "/kaggle/input/**/*.mp4",
    ])

    print(f"📦 [1] CogVideoX-Fun InP: {model_dir}")
    print(f"📦 [2] TrajectoryCrafter: {transformer_dir}")
    print(f"🎯 [3] Stage 1 Checkpoint: {stage1_ckpt}")
    print(f"🎯 [4] Stage 2 Checkpoint: {stage2_ckpt}")
    print(f"🎬 [5] Video Thử nghiệm: {video_path}")

    assert model_dir and os.path.exists(model_dir), f"Không tìm thấy Model CogVideoX-Fun InP tại: {model_dir}"
    assert video_path and os.path.exists(video_path), f"Không tìm thấy Video đầu vào tại: {video_path}"

    out_dir = "/kaggle/working/eval_scaffold_pairwise"
    os.makedirs(out_dir, exist_ok=True)

    # Import pipeline and patch Warper3D
    from pipeline_v3.geometry.warper3d import Warper3D
    from pipeline_v3.inference_v3 import PipelineV3
    patch_warper_class(Warper3D)

    # Build options
    class Args:
        pass
    opts = Args()
    opts.model_name = model_dir
    opts.transformer_path = transformer_dir
    opts.use_official_weights = False
    opts.dora_checkpoint = stage1_ckpt
    opts.dora_r = 16
    opts.dora_alpha = 32.0
    opts.stage2_checkpoint = stage2_ckpt
    opts.video_length = 49
    opts.stride = 1
    opts.sample_size = [384, 672]
    opts.fps = 10
    opts.seed = 42
    opts.device = "cuda:0" if torch.cuda.is_available() else "cpu"
    opts.dtype = "bf16"
    opts.low_gpu_memory_mode = False
    opts.clean_mask = True
    opts.heal_hole_size = 25
    opts.no_heal_holes = False
    opts.mask_threshold = 0.85
    opts.prompt = ""
    opts.negative_prompt = "blur, distortion, jitter, flickering, low quality"
    opts.guidance_scale = 6.0
    opts.inference_steps = 30
    opts.quiet = False
    opts.out_dir = out_dir
    opts.use_mfs_scaffold = False

    pipeline = PipelineV3(opts)

    # Test cases: Tier 1 (Normal) & Tier 4 (Stress case)
    test_trajectories = [
        {"name": "Tier 1: Normal (Pan -3 deg)", "tag": "tier1_pan3", "pose": [0.0, -3.0, 0.0, 0.0, 0.0]},
        {"name": "Tier 4: Stress (Pan -15 deg, Dolly 5.0m)", "tag": "tier4_dolly5m", "pose": [0.0, -15.0, 5.0, 0.0, 0.0]},
    ]

    for traj in test_trajectories:
        t_name = traj["name"]
        t_tag = traj["tag"]
        t_pose = traj["pose"]

        print(f"\n" + "=" * 80)
        print(f"🎬 BẮT ĐẦU ĐÁNH GIÁ: {t_name}")
        print(f"📐 Target Pose: {t_pose}")
        print("=" * 80)

        # 1. Run Old Scaffold (Baseline)
        print(f"\n[1/2] Đang chạy với 3D Scaffold CŨ (Single-Frame 2.5D)...")
        opts.use_mfs_scaffold = False
        opts.tag = f"old_{t_tag}"
        pipeline.run(video_path, target_pose=t_pose)

        old_render = os.path.join(out_dir, f"render_old_{t_tag}.mp4")
        old_gen = os.path.join(out_dir, f"gen_old_{t_tag}.mp4")

        # 2. Run New MFS-Scaffold
        print(f"\n[2/2] Đang chạy với MFS-Scaffold MỚI (Multi-Frame Priority Infilling)...")
        opts.use_mfs_scaffold = True
        opts.neighbor_radius = 3
        opts.no_use_all_frames = False
        opts.no_cull_grazing = False
        opts.max_grazing_angle = 55.0
        opts.no_depth_edge_filter = False
        opts.no_align_depth_scale = False
        opts.tag = f"new_{t_tag}"
        pipeline.run(video_path, target_pose=t_pose)

        new_render = os.path.join(out_dir, f"render_new_{t_tag}.mp4")
        new_gen = os.path.join(out_dir, f"gen_new_{t_tag}.mp4")

        # 3. Stitch 5-column video
        grid_file = os.path.join(out_dir, f"comparison_pair_{t_tag}.mp4")
        try:
            create_comparison_grid(video_path, old_render, new_render, old_gen, new_gen, grid_file, fps=opts.fps)
        except Exception as e:
            print(f"⚠️ Không thể tạo video ghép 5 cột cho {t_tag}: {e}")

    print("\n" + "=" * 80)
    print(f"🎉 HOÀN THÀNH SO SÁNH THEO CẶP! Các video đã được lưu tại: {out_dir}")
    print("=" * 80)


if __name__ == "__main__":
    run_pairwise_eval()
