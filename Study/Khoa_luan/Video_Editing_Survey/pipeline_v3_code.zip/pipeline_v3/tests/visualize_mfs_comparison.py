"""
Visual Comparison: Old Single-Frame Scaffold vs New Multi-Frame Priority Scaffold (MFS-Scaffold).
Demonstrates how MFS-Scaffold resolves:
1. Grazing-angle surface tearing / stretching (eliminating 2.5D 'spaghetti' distortion)
2. Silhouette depth edge bleeding
3. Black disocclusion holes by hierarchical multi-frame infilling
"""

import os
import sys
import cv2
import torch
import numpy as np

sys.path.insert(0, os.path.abspath("."))
from pipeline_v3.geometry.warper3d import Warper3D
from pipeline_v3.geometry.trajectory import generate_camera_trajectory


def create_indoor_depth_map(h, w, device="cpu"):
    """
    Synthesizes a realistic indoor depth map with a foreground object (at ~1.8m)
    and a background wall/floor (at ~3.5m - 5.0m).
    """
    y, x = np.meshgrid(np.linspace(0, 1, h), np.linspace(0, 1, w), indexing="ij")
    
    # Ground plane and back wall
    wall_depth = 3.5 + 1.5 * y
    
    # Foreground centered subject/table (depth ~ 1.8m)
    fg_mask = (y > 0.35) & (y < 0.85) & (x > 0.25) & (x < 0.75)
    depth = wall_depth.copy()
    depth[fg_mask] = 1.8
    
    # Smooth edges slightly
    depth = cv2.GaussianBlur(depth.astype(np.float32), (9, 9), 2.0)
    return torch.from_numpy(depth).unsqueeze(0).unsqueeze(0).to(device).float()


def run_comparison():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Running MFS-Scaffold visual comparison on {device}...")
    
    warper = Warper3D(device=device)
    
    # Load user sample frames
    debug_dir = r"C:\Users\VU\.gemini\antigravity\brain\078f1890-f73d-46c0-9410-37226f8e4faa\user_video_debug"
    frame_names = ["1_frame_00.jpg", "1_frame_12.jpg", "1_frame_24.jpg", "1_frame_36.jpg", "1_frame_48.jpg"]
    
    raw_frames = []
    for fn in frame_names:
        fp = os.path.join(debug_dir, fn)
        if os.path.exists(fp):
            img = cv2.imread(fp)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            raw_frames.append(img)
            
    if len(raw_frames) < 5:
        print("[Warning] Could not load all user frames, creating synthetic patterns...")
        h, w = 384, 672
        raw_frames = []
        for i in range(5):
            arr = np.zeros((h, w, 3), dtype=np.uint8)
            arr[:, :, 0] = int(i * 50)
            arr[:, :, 1] = int(120)
            arr[:, :, 2] = int(200 - i * 40)
            cv2.putText(arr, f"Frame {i*12}", (w//3, h//2), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 4)
            raw_frames.append(arr)
            
    h, w, _ = raw_frames[0].shape
    num_frames = len(raw_frames)
    
    # Convert frames to tensor in [-1, 1]
    frames_np = np.stack(raw_frames, axis=0).astype(np.float32) / 127.5 - 1.0
    frames_tensor = torch.from_numpy(frames_np).permute(0, 3, 1, 2).to(device).float()
    
    # Depth maps for each frame
    base_depth = create_indoor_depth_map(h, w, device=device)
    depths_tensor = base_depth.repeat(num_frames, 1, 1, 1)
    
    # Camera intrinsics
    f = 500.0
    cx = w / 2.0
    cy = h / 2.0
    K = torch.tensor([[f, 0.0, cx], [0.0, f, cy], [0.0, 0.0, 1.0]], dtype=torch.float32, device=device).repeat(num_frames, 1, 1)
    
    # Camera trajectory: realistic stress test (Pan -20 degrees, translation 1.2m)
    c2w_anchor = torch.tensor(
        [[-1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, -1.0, 0.0], [0.0, 0.0, 0.0, 1.0]],
        dtype=torch.float32,
        device=device,
    ).unsqueeze(0)
    
    pose_s, pose_t = generate_camera_trajectory(
        c2w_anchor, theta=0.0, phi=-20.0, d_r=1.2, d_x=0.2, d_y=0.0, num_frames=num_frames, device=device
    )
    
    target_idx = num_frames - 1  # Last frame where camera rotation is maximal (-45 deg)
    
    print(f"Generating comparison for Frame {target_idx*12} under Pan -45 deg...")
    
    # 1. Baseline Old Scaffold: Single Frame (Frame 0 warped to target pose of frame target_idx)
    # No grazing-angle culling, no edge filtering, no multi-frame
    old_warp, old_mask, _ = warper.forward_warp(
        frame1=frames_tensor[0:1],
        mask1=None,
        depth1=depths_tensor[0:1],
        transformation1=pose_s[0:1],
        transformation2=pose_t[target_idx : target_idx + 1],
        intrinsic1=K[0:1],
        intrinsic2=K[target_idx : target_idx + 1],
        clean_mask=True,
        heal_holes=False,
        cull_grazing_angles=False,
        filter_depth_edges=False,
    )
    
    # 2. New MFS-Scaffold: Multi-Frame Priority Splatting
    # Grazing angle culling (55 deg) + Depth edge filter + Multi-frame infilling + Hole healing
    new_warp, new_mask, _ = warper.multi_frame_forward_warp(
        frames=frames_tensor,
        depths=depths_tensor,
        transformation_s=pose_s,
        transformation_t=pose_t,
        intrinsic_s=K,
        intrinsic_t=K,
        target_idx=target_idx,
        neighbor_radius=3,
        use_all_frames=True,
        cull_grazing_angles=True,
        max_grazing_angle=55.0,
        filter_depth_edges=True,
        align_depth_scale=True,
        clean_mask=True,
        heal_holes=True,
        max_hole_area=25,
    )
    
    # Convert tensors to uint8 RGB
    def to_rgb(t):
        arr = ((t.squeeze(0).permute(1, 2, 0).cpu().numpy() + 1.0) * 127.5).clip(0, 255).astype(np.uint8)
        return arr
        
    def mask_to_rgb(m):
        arr = (m.squeeze(0).squeeze(0).cpu().numpy() * 255.0).clip(0, 255).astype(np.uint8)
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
        
    orig_img = raw_frames[target_idx]
    old_img = to_rgb(old_warp)
    old_mask_rgb = mask_to_rgb(old_mask)
    new_img = to_rgb(new_warp)
    new_mask_rgb = mask_to_rgb(new_mask)
    
    # Compute Diff / Infill Mask (pixels healed/filled by MFS that were empty or culled)
    diff_mask = ((new_mask - old_mask).clamp(min=0.0).squeeze().cpu().numpy() * 255).clip(0, 255).astype(np.uint8)
    diff_rgb = np.zeros_like(orig_img)
    diff_rgb[:, :, 1] = diff_mask  # Green for multi-frame infilled pixels
    
    # Label headers
    font = cv2.FONT_HERSHEY_SIMPLEX
    def add_label(img, text, subtext=""):
        res = img.copy()
        cv2.rectangle(res, (0, 0), (w, 55), (20, 20, 20), -1)
        cv2.putText(res, text, (15, 25), font, 0.7, (255, 255, 255), 2)
        if subtext:
            cv2.putText(res, subtext, (15, 48), font, 0.5, (0, 230, 255), 1)
        return res

    col1 = add_label(orig_img, "1. Input Video Frame", f"Frame {target_idx*12} (Reference)")
    col2 = add_label(old_img, "2. Old 2.5D Scaffold (Single-Frame)", "Severe Grazing Distortion & Spaghetti Tearing")
    col3 = add_label(new_img, "3. New MFS-Scaffold (Multi-Frame)", "Culled Grazing Angles + Multi-Frame Infilled")
    col4 = add_label(diff_rgb, "4. Multi-View Infilled Regions", "Green: Geometry Recovered from other Frames")
    
    # Stack row 1: Color Images
    row1 = np.hstack([col1, col2, col3, col4])
    
    # Stack row 2: Masks & Diagnostics
    col1_m = add_label(cv2.cvtColor((base_depth.squeeze().cpu().numpy() / 5.0 * 255).astype(np.uint8), cv2.COLOR_GRAY2RGB), "Depth Map", "Geometry Proxy")
    col2_m = add_label(old_mask_rgb, "Old Scaffold Mask", f"Coverage: {old_mask.mean().item()*100:.1f}% (Forced Corrupted Pixels)")
    col3_m = add_label(new_mask_rgb, "New MFS Valid Mask", f"Coverage: {new_mask.mean().item()*100:.1f}% (Clean, Verified Geometry)")
    
    # Overlay of New Render on original black disocclusion
    overlay = new_img.copy()
    overlay[new_mask.squeeze().cpu().numpy() < 0.5] = [255, 0, 80]  # Pink for remaining holes for Stage 1
    col4_m = add_label(overlay, "Stage 1 Inpainting Target", "Pink: Clean Holes for Stage 1 Inpainter")
    
    row2 = np.hstack([col1_m, col2_m, col3_m, col4_m])
    
    comparison_canvas = np.vstack([row1, row2])
    
    out_dir = r"C:\Users\VU\.gemini\antigravity\brain\078f1890-f73d-46c0-9410-37226f8e4faa"
    out_path = os.path.join(out_dir, "mfs_scaffold_comparison.png")
    cv2.imwrite(out_path, cv2.cvtColor(comparison_canvas, cv2.COLOR_RGB2BGR))
    print(f"--> Saved comparison artifact to: {out_path}")
    print(f"Old Scaffold Coverage: {old_mask.mean().item()*100:.2f}%")
    print(f"New MFS-Scaffold Coverage: {new_mask.mean().item()*100:.2f}%")


if __name__ == "__main__":
    run_comparison()
