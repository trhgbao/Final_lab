"""
Unit tests for Multi-Frame Priority Splatting (MFS-Scaffold) in Warper3D.
Verifies:
1. Surface normal computation and unit normalization
2. Grazing-angle surface culling under 45-degree rotation
3. Depth scale/shift alignment in disparity space
4. Multi-frame priority infilling (Tier 0 anchor lock + Tier 1/2 neighbor infilling)
"""

import sys, os
sys.path.insert(0, os.path.abspath("."))
import torch
import numpy as np
from pipeline_v3.geometry.warper3d import Warper3D


def create_mock_camera(b=1, h=128, w=128, device="cpu"):
    """Creates synthetic camera intrinsics and identity poses."""
    K = torch.tensor([
        [150.0, 0.0, w / 2.0],
        [0.0, 150.0, h / 2.0],
        [0.0, 0.0, 1.0],
    ], device=device).unsqueeze(0).repeat(b, 1, 1)

    c2w = torch.eye(4, device=device).unsqueeze(0).repeat(b, 1, 1)
    return K, c2w


def test_surface_normals():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    warper = Warper3D(device=device)
    b, h, w = 1, 64, 64
    K, _ = create_mock_camera(b, h, w, device=device)

    # Flat plane at depth = 2.0 meters
    depth = torch.ones((b, 1, h, w), device=device) * 2.0

    normals = warper.compute_surface_normals(depth, K)
    assert normals.shape == (b, 3, h, w)

    # Unit norm check
    norm = torch.norm(normals, dim=1)
    assert torch.allclose(norm, torch.ones_like(norm), atol=1e-4)

    # For a flat frontal plane facing camera, normal should point primarily along Z: [0, 0, -1] or [0, 0, 1]
    assert normals[:, 2].abs().mean() > 0.9
    print("[PASS] test_surface_normals passed")


def test_grazing_angle_culling():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    warper = Warper3D(device=device)
    b, h, w = 1, 64, 64
    K, _ = create_mock_camera(b, h, w, device=device)

    # Create a flat frontal plane at depth = 2.0m
    depth1 = torch.ones((b, 1, h, w), device=device) * 2.0
    w2c_1 = torch.eye(4, device=device).unsqueeze(0).float()

    # Case A: Orbit camera by 70 degrees around object at (0, 0, 2.0) -> grazing angle > 55 deg
    theta_large = float(np.deg2rad(70.0))
    R_large = torch.tensor([
        [np.cos(theta_large), 0.0, -np.sin(theta_large)],
        [0.0, 1.0, 0.0],
        [np.sin(theta_large), 0.0, np.cos(theta_large)]
    ], device=device).float()
    cam_pos_large = torch.tensor([2.0 * np.sin(theta_large), 0.0, 2.0 - 2.0 * np.cos(theta_large)], device=device).float()
    t_large = -torch.matmul(R_large, cam_pos_large)

    w2c_large = torch.eye(4, device=device).unsqueeze(0).float()
    w2c_large[0, :3, :3] = R_large
    w2c_large[0, :3, 3] = t_large

    grazing_mask_large = warper.compute_grazing_angle_mask(
        depth1, w2c_1, w2c_large, K, max_angle_deg=55.0
    )
    # Since 70 deg > 55 deg, surface should be culled (mean == 0.0)
    assert grazing_mask_large.mean().item() == 0.0

    # Case B: Orbit camera by 30 degrees -> viewing angle 30 deg < 55 deg threshold -> preserved
    theta_small = float(np.deg2rad(30.0))
    R_small = torch.tensor([
        [np.cos(theta_small), 0.0, -np.sin(theta_small)],
        [0.0, 1.0, 0.0],
        [np.sin(theta_small), 0.0, np.cos(theta_small)]
    ], device=device).float()
    cam_pos_small = torch.tensor([2.0 * np.sin(theta_small), 0.0, 2.0 - 2.0 * np.cos(theta_small)], device=device).float()
    t_small = -torch.matmul(R_small, cam_pos_small)

    w2c_small = torch.eye(4, device=device).unsqueeze(0).float()
    w2c_small[0, :3, :3] = R_small
    w2c_small[0, :3, 3] = t_small

    grazing_mask_small = warper.compute_grazing_angle_mask(
        depth1, w2c_1, w2c_small, K, max_angle_deg=55.0
    )
    assert grazing_mask_small.mean().item() == 1.0
    print("[PASS] test_grazing_angle_culling passed (both culling and preservation verified)")


def test_align_depth_scale():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    warper = Warper3D(device=device)
    b, h, w = 1, 64, 64

    # Target depth: gradient from 1.0 to 5.0
    tgt_depth = torch.linspace(1.0, 5.0, h * w, device=device).view(b, 1, h, w)

    # Source depth with synthetic scale 1.5 and bias in disparity
    tgt_inv = 1.0 / tgt_depth
    src_inv = tgt_inv * 0.7 + 0.1
    src_depth = 1.0 / src_inv

    covisible = torch.ones((b, 1, h, w), device=device)

    aligned = warper.align_depth_scale(src_depth, tgt_depth, covisible)
    assert aligned.shape == (b, 1, h, w)

    # Check error between aligned depth and target depth
    diff = (aligned - tgt_depth).abs().mean().item()
    assert diff < 0.15
    print(f"[PASS] test_align_depth_scale passed (mean error: {diff:.4f})")


def test_multi_frame_priority_warp():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    warper = Warper3D(device=device)
    num_frames, h, w = 5, 64, 64

    # Synthetic video frames with distinct colors
    frames = torch.zeros((num_frames, 3, h, w), device=device)
    for i in range(num_frames):
        frames[i, 0] = (i / num_frames) * 2.0 - 1.0  # distinct red channel

    # Synthetic depths
    depths = torch.ones((num_frames, 1, h, w), device=device) * 2.5

    # Trajectory: camera moving sideways in source trajectory
    K, _ = create_mock_camera(1, h, w, device=device)
    poses_s = torch.eye(4, device=device).unsqueeze(0).repeat(num_frames, 1, 1)
    for i in range(num_frames):
        poses_s[i, 0, 3] = (i - 2) * 0.1  # camera translated across frames

    # Target trajectory: target pose for frame 2 has a +0.15 X shift
    poses_t = poses_s.clone()
    poses_t[2, 0, 3] += 0.15

    # 1. Single-frame warping coverage for frame 2
    _, single_mask, _ = warper.forward_warp(
        frames[2:3], None, depths[2:3], poses_s[2:3], poses_t[2:3], K, K,
        clean_mask=False, heal_holes=False
    )

    # 2. Multi-frame priority warping for frame 2
    canvas, multi_mask, flow = warper.multi_frame_forward_warp(
        frames=frames,
        depths=depths,
        transformation_s=poses_s,
        transformation_t=poses_t,
        intrinsic_s=K,
        intrinsic_t=K,
        target_idx=2,
        neighbor_radius=2,
        use_all_frames=True,
        cull_grazing_angles=True,
        max_grazing_angle=60.0,
        clean_mask=False,
        heal_holes=False
    )

    assert canvas.shape == (1, 3, h, w)
    assert multi_mask.shape == (1, 1, h, w)
    # Multi-frame MUST increase or equal coverage by infilling disoccluded pixels from neighbors!
    assert multi_mask.mean().item() >= single_mask.mean().item()
    assert multi_mask.mean().item() > 0.9  # Should achieve near-complete coverage (>90%)
    print(
        f"[PASS] test_multi_frame_priority_warp passed "
        f"(single: {single_mask.mean().item()*100:.1f}% -> multi: {multi_mask.mean().item()*100:.1f}%)"
    )


if __name__ == "__main__":
    test_surface_normals()
    test_grazing_angle_culling()
    test_align_depth_scale()
    test_multi_frame_priority_warp()
    print("\nAll MFS-Scaffold tests passed successfully!")
